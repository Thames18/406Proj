public class IO implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	public void Input(){	

	}

	public void display(String string) {

	}
}