import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.Array;
import java.security.KeyStore.Entry;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.Vector;

public class Survey extends Main implements java.io.Serializable{
	private static final long serialVersionUID = 1L;
	protected Vector<Question> questions=new Vector<Question>();
	protected IO IO=new Output();
	protected String nameOfSurvey;
	HashMap<String,Vector<ResponseCorrectAnswer>> response=new HashMap<String,Vector<ResponseCorrectAnswer>>();

	public Survey() {

	}

	public void setQuestions(Vector<Question> questions) {
		this.questions = questions;
	}

	public Vector<Question> getQuestions() {
		return this.questions;
	}

	public static  Survey load(String surveyList, String type) {
		Survey abc=new Survey();
		System.out.println("Select a " + type);
		String temp = "";
		String[] surveys = surveyList.split("\n");
		for (int i = 0; i < surveys.length; i++){
			System.out.println("" + (i + 1) + ") "+ surveys[i].substring(0, surveys[i].lastIndexOf('.')));
		}
		System.out.println("" + (surveys.length + 1) + ") Exit");
		int choice = -1;
		Scanner scan = new Scanner(System.in);
		temp = scan.nextLine();
		try{
			choice = Integer.parseInt(temp);
		} 
		catch (Exception e){

			System.out.println("Invalid entry, enter a number for a " + type+ " \n\n\n");
			load(surveyList, type);
			scan.close();	
		}

		if (choice > surveys.length + 1 || choice < 1){
			System.out.println("Invalid entry, enter a number for a " + type+ " \n\n\n");
			load(surveyList, type);
			scan.close();	
		}
		else{
			if (choice == surveys.length + 1){
				try {
					System.out.println("\n");
					MenuOption();
				} 
				catch (IOException e) {
					e.printStackTrace();
				}
			}
			try{  
				FileInputStream fis = new FileInputStream(type.toLowerCase()+ "s\\" + surveys[choice - 1]);
				ObjectInputStream ois = new ObjectInputStream(fis);
				switch (type.toLowerCase()){
				case "survey":
					abc = (Survey) ois.readObject();
					break;
				case "test":
					abc = (Test) ois.readObject();
					break;
				default:

					break;
				}
				fis.close();
				ois.close();
			} 
			catch (Exception e){
				System.out.println("File was not serialized correctly or may be an old version \n");
				scan.close();	
			}
		}
		abc.displaySurvey();
		return abc;
	}

	public  void savetofile(Survey currentSurvey) throws IOException {

		File createFile = new File("surveys\\" + this.nameOfSurvey + ".dat");

		if (!createFile.exists())
			createFile.createNewFile();

		File testsFile = new File("C:/Users/musta/Desktop/CPS 406/surveys.txt");

		if (!testsFile.exists())
			testsFile.createNewFile();

		FileOutputStream fileOut = new FileOutputStream(createFile);
		ObjectOutputStream out = new ObjectOutputStream(fileOut);
		out.writeObject(this);

		FileReader fr = new FileReader("C:/Users/musta/Desktop/CPS 406/surveys.txt");
		BufferedReader br1 = new BufferedReader(fr);
		String collection = "";
		String temp = br1.readLine();
		while (temp != null){
			if (!temp.toLowerCase().equals((this.nameOfSurvey + ".dat").toLowerCase())){
				collection = collection + temp + "\n";
			}
			temp = br1.readLine();
		}
		FileWriter fw = new FileWriter("C:/Users/musta/Desktop/CPS 406/surveys.txt");
		BufferedWriter bw = new BufferedWriter(fw);
		bw.write(collection + this.nameOfSurvey + ".dat\n");

		br1.close();
		bw.close();
		fw.close();
		out.close();
		fileOut.close();	
	}

	public void displaySurvey(){
		System.out.println("Displaying the survey with the questions created \n");
		this.IO.display("Name of the Survey - "+this.nameOfSurvey+"\n");	
		for(int i=0;i<questions.size();i++){
			this.IO.display("" + (i + 1) + ")");
			questions.get(i).display(this.IO);
		}
		this.IO.display("\n");
	}


	protected void createQuestion(int choice) throws IOException{
		Question ques = null;
		switch (choice){
		case 1:
			System.out.println("You have selected to " + choice);
			ques = new TF();
			ques.createques();
			break;
		case 2:
			System.out.println("You have selected to " + choice);
			ques= new MCQ();
			ques.createques();
			break;
		case 3:
			super.SurveyMenu();
			break;
		default: 
			System.out.println("Please select the valid options only \n");
			break;
		}
		questions.add(ques);	
		questionOptions();
	}

	public Survey createSurvey() throws IOException {
		System.out.println("type name of survey");
		Scanner reader1 = new Scanner(System.in);  
		String name_ = reader1.nextLine();
		nameOfSurvey= name_;
		questionOptions();
		return this;	
	}	

	public void questionOptions(){

		System.out.println("1.) Add a new T/F question:"); 
		System.out.println("2.) Add a new multiple choice question");
		System.out.println("3.) Previous Menu");


		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String var;
		try {
			var = br.readLine();
			int n; 
			try{
				n=Integer.parseInt(var);
				if(n>=1 || n<=3){
					createQuestion(n);
				}
				else{
					System.out.println("Please select the valid options only \n");
					questionOptions();
				}
			}
			catch (Exception e){
				System.out.println("Please select the valid options only \n");
				questionOptions();	
			}
		} 
		catch (IOException e1) {
			e1.printStackTrace();
		}
	}

	public void modify(int i) {
		Question question = this.questions.get(i);
		question.modifyy();
	}

	
	public static  Survey loads(String surveyList, String type) {
		Survey abc=new Survey();
		System.out.println("Select a " + type);
		String temp = "";
		String[] surveys = surveyList.split("\n");
		for (int i = 0; i < surveys.length; i++){
			System.out.println("" + (i + 1) + ") "+ surveys[i].substring(0, surveys[i].lastIndexOf('.')));
		}
		System.out.println("" + (surveys.length + 1) + ") Exit");
		int choice = -1;
		Scanner scan = new Scanner(System.in);
		temp = scan.nextLine();
		try{
			choice = Integer.parseInt(temp);
		} 
		catch (Exception e){
			System.out.println("Invalid entry, enter a number for a " + type+ " \n\n\n");
			loads(surveyList, type);
			scan.close();	
		}

		if (choice > surveys.length + 1 || choice < 1){
			System.out.println("Invalid entry, enter a number for a " + type+ " \n\n\n");
			loads(surveyList, type);
			scan.close();	
		}
		else{
			if (choice == surveys.length + 1){
				try {
					System.out.println("\n");
					MenuOption();
				} 
				catch (IOException e) {
					e.printStackTrace();
				}
			}
			try{  
				FileInputStream fis = new FileInputStream(type.toLowerCase()+ "s\\" + surveys[choice - 1]);
				ObjectInputStream ois = new ObjectInputStream(fis);
				switch (type.toLowerCase()){
				case "survey":
					abc = (Survey) ois.readObject();
					break;
				case "test":
					abc = (Test) ois.readObject();
					break;
				default:
					break;
				}
				fis.close();
				ois.close();
			} 
			catch (Exception e){
				System.out.println("File was not serialized correctly or may be an old version \n");
				scan.close();	
			}
		}
		abc.displaySurveyTakeTest();
		return abc;
	}

	public void displaySurveyTakeTest() {


	}

}
