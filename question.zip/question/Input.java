public class Input extends IO {

	private static final long serialVersionUID = 1L;

	public IO getInput() {
		throw new UnsupportedOperationException();
	}
}