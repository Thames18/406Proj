public class Input extends IO
 {
	public static final long serialVersionUID = 1L;
	public IO getInput() {
		throw new UnsupportedOperationException();
	}
}