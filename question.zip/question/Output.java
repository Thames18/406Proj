public class Output extends IO {

	private static final long serialVersionUID = 1L;

	public void display(String stream) {
		System.out.println(stream);
		}
	}