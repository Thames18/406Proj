public class Student extends User {
    public Student (){
        super();
    }
    public Student (String name, String ID, String pass){
        super(name, ID, pass);
    }
}
