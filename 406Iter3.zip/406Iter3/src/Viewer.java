import javax.swing.*;
public class Viewer {
    public static void main(String[] args){
        JFrame f = new Frame();
        f.setVisible(true);
    }
}
