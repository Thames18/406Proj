public class Instructor extends User{
    public Instructor(){
        super();
    }
    public Instructor(String name, String ID, String pass){
        super(name, ID, pass
        );
    }
}
